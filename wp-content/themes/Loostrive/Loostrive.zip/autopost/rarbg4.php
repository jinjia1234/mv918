{
    "rating": {
        "max": 10,
        "average": "7.1",
        "numRaters": 1145,
        "min": 0
    },
    "author": [
        {
            "name": "加芙列拉·考珀斯维特 Gabriela Cowperthwaite"
        }
    ],
    "alt_title": "梅根·利维 / 梅根李维(台)",
    "image": "https://img1.doubanio.com/view/movie_poster_cover/ipst/public/p2452064448.jpg",
    "title": "Megan Leavey",
    "summary": "凯特·玛拉在片中饰演一位严纪守律的海军陆战队下士。她同她的军犬一起，在伊拉克拯救了许多人的生命。",
    "attrs": {
        "language": [
            "英语"
        ],
        "pubdate": [
            "2017-05-07(蒙特克莱电影节)",
            "2017-06-09(美国)"
        ],
        "title": [
            "Megan Leavey"
        ],
        "country": [
            "美国"
        ],
        "writer": [
            "帕梅拉·格雷 Pamela Gray",
            "安妮·玛莫罗 Annie Mumolo",
            "蒂姆·洛夫斯特特 Tim Lovestedt"
        ],
        "director": [
            "加芙列拉·考珀斯维特 Gabriela Cowperthwaite"
        ],
        "cast": [
            "凯特·玛拉 Kate Mara",
            "汤姆·费尔顿 Tom Felton",
            "布莱德利·惠特福德 Bradley Whitford",
            "杰拉丁妮·詹姆斯 Geraldine James",
            "科曼 Common",
            "埃迪·法可 Edie Falco",
            "威尔·帕顿 Will Patton",
            "拉蒙·罗德里格兹 Ramon Rodriguez",
            "珊农·塔伯特 Shannon Tarbet",
            "米格尔·戈麦斯 Miguel Gomez",
            "乔纳森·霍华德 Jonathan Howard",
            "乔治·韦伯斯特 George Webster",
            "克里·约翰逊 Corey Johnson",
            "山姆·基利 Sam Keeley",
            "凯萨琳·戴尔 Catherine Dyer",
            "迈尔斯·穆森登 Miles Mussenden",
            "玛丽娜·马修斯 Melina Matthews",
            "帕克·索耶 Parker Sawyers"
        ],
        "movie_duration": [
            "116分钟"
        ],
        "year": [
            "2017"
        ],
        "movie_type": [
            "剧情",
            "传记",
            "战争"
        ]
    },
    "id": "https://api.douban.com/movie/26610786",
    "mobile_link": "https://m.douban.com/movie/subject/26610786/",
    "alt": "https://movie.douban.com/movie/26610786",
    "tags": [
        {
            "count": 275,
            "name": "战争"
        },
        {
            "count": 226,
            "name": "美国"
        },
        {
            "count": 204,
            "name": "狗"
        },
        {
            "count": 177,
            "name": "传记"
        },
        {
            "count": 153,
            "name": "2017"
        },
        {
            "count": 147,
            "name": "剧情"
        },
        {
            "count": 141,
            "name": "温情"
        },
        {
            "count": 110,
            "name": "美军"
        }
    ]
}